package com.example.vednorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button viewsubscribers, viewnewspapers, viewmagazines, notifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        viewsubscribers = findViewById(R.id.view_subscribers);
        viewnewspapers = findViewById(R.id.view_newspapers);
        viewmagazines = findViewById(R.id.view_magazines);
        notifications = findViewById(R.id.notifications);

        viewsubscribers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Subscribers.class));
            }
        });

        viewnewspapers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Newspapers.class));
            }
        });

        viewmagazines.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Magazines.class));
            }
        });

        notifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Notifications.class));
            }
        });
    }
}