package com.example.subscriptionapp.Models;

public class Notificationmodel {

    String message, id;

}
