package com.example.subscriptionapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CalendarView;

import com.example.subscriptionapp.Adapters.Eventadapter;
import com.example.subscriptionapp.Models.eventmodel;
import com.example.subscriptionapp.databinding.ActivityCalendareventeditBinding;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;

public class Calendareventedit extends AppCompatActivity {
    Button addButton;
    TextInputLayout editText;
    CalendarView calender;
    String selectedDate;
    ArrayList<eventmodel> eventholder;
    Eventadapter adapter;
    RecyclerView recyclerView;
    String mobnumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendareventedit);
    }
}