package com.example.subscriptionapp.Models;

public class eventmodel {
    String mobnumber,event,datetime;
    String id;

    String message;

    public eventmodel(String mobnumber, String event, String datetime, String id, String message) {
        this.mobnumber = mobnumber;
        this.event = event;
        this.datetime = datetime;
        this.id = id;
        this.message = message;
    }

    public eventmodel(String mobnumber, String event, String id, String datetime) {
        this.mobnumber = mobnumber;
        this.event = event;
        this.datetime = datetime;
        this.id = id;
    }

    public eventmodel(String mobnumber, String event, String datetime) {
        this.mobnumber = mobnumber;
        this.event = event;
        this.datetime = datetime;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public eventmodel(String message) {
        this.message = message;


    }

    public String getMobnumber() {
        return mobnumber;
    }

    public void setMobnumber(String mobnumber) {
        this.mobnumber = mobnumber;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }
}
